package kr.or.ddit.mp.dao.mypageEatDealQnA;

import java.util.List;

import kr.or.ddit.mp.vo.mypageEatDealQnA.EatqaVO;

public interface IMypageEatDealQnADao {
	
	
	public List<EatqaVO> getMyEatDealQnA(EatqaVO evo); // 내가 작성한 eat deal qna출력

	
	
	
}
