package kr.or.ddit.mp.model;
import java.util.ArrayList;

import kr.or.ddit.mp.vo.eatdeal.RequestVO;

public class DataModel {
 
  
    public static ArrayList<RequestVO> orderInfo = new ArrayList<RequestVO>();
    public static boolean isFirstLogin = true;
    public static boolean isFirstZone = true;
    
}